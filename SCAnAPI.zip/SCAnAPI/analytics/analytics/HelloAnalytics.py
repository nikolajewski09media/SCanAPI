"""Hello Analytics Reporting API V4."""
import csv
import datetime

from apiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials

domains = []
with open('domains.csv') as csvDataFile:
    reader = csv.reader(csvDataFile, delimiter=';')
    for row in reader:
        for item in row:
            if item not in row:
                domains.append('')
            else:
                domains.append(item)

SCOPES = ['https://www.googleapis.com/auth/analytics.readonly']
KEY_FILE_LOCATION = 'client_secrets.json'
VIEW_ID = ''


def initialize_analyticsreporting():
    """Initializes an Analytics Reporting API V4 service object.

    Returns:
      An authorized Analytics Reporting API V4 service object.
    """
    credentials = ServiceAccountCredentials.from_json_keyfile_name(
        KEY_FILE_LOCATION, SCOPES)

    # Build the service object.
    analytics = build('analyticsreporting', 'v4', credentials=credentials)

    return analytics


def get_report(analytics, VIEW_ID):
    """Queries the Analytics Reporting API V4.

    Args:
      analytics: An authorized Analytics Reporting API V4 service object.
    Returns:
      The Analytics Reporting API V4 response.
    """
    return analytics.reports().batchGet(
        body={
            'reportRequests': [
                {
                    'viewId': VIEW_ID,
                    'dateRanges': [{'startDate': '2020-05-01', 'endDate': '2020-05-31'}],
                    "metrics": [{"expression": "ga:users"}],
                    'dimensions': [{'name': 'ga:channelGrouping'}],
                    # "includeEmptyRows": "true"
                }]
        }
    ).execute()


def print2dic(response, dicto, domain):
    for report in response.get('reports', []):
        for row in report.get('data', {}).get('rows', []):
            dimensions = row.get('dimensions', [])
            dateRangeValues = row.get('metrics', [])
            for i, values in enumerate(dateRangeValues):
                for dimension, value in zip(dimensions, values.get('values')):
                    dicto[dimension] = value
    return dicto


def dic2array(dict):
    ab = []
    if dict == {}:
        dict['(Other)'] = '-'
        dict['Direct'] = '-'
        dict['Organic Search'] = '-'
        dict['Paid Search'] = '-'
        dict['Referral'] = '-'
        dict['Social'] = '-'
    try:
        ab.append(dict["(Other)"])
    except:
        dict['(Other)'] = '-'
        ab.append(dict["(Other)"])
    finally:
        try:
            ab.append(dict["Direct"])
        except:
            dict['Direct'] = '-'
            ab.append(dict["Direct"])
        finally:
            try:
                ab.append(dict["Organic Search"])
            except:
                dict['Organic Search'] = '-'
                ab.append(dict["Organic Search"])
            finally:
                try:
                    ab.append(dict["Paid Search"])
                except Exception:
                    dict['Paid Search'] = '-'
                    ab.append(dict["Paid Search"])
                finally:
                    try:
                        ab.append(dict["Referral"])
                    except Exception:
                        dict['Referral'] = '-'
                        ab.append(dict["Referral"])
                    finally:
                        try:
                            ab.append(dict["Social"])
                        except Exception:
                            dict['Social'] = '-'
                        finally:
                            return ab


def array2csv(array):
    with open(f'REPORT_Analytics_Akquisition_{datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")}.csv', 'w',
              newline='') as csvfile:  #
        fieldnames = [  # 'domain',
            '(Other)',
            'Direct',
            'Organic Search',
            'Paid Search',
            'Referral',
            'Social'
        ]
        csvWriter = csv.DictWriter(csvfile, delimiter=';', fieldnames=fieldnames, quoting=csv.QUOTE_NONE)
        newIterator = iter(array)
        csvWriter.writeheader()
        for item in range(0, int(len(array) / 6)):
            csvWriter.writerow({  # 'domain': next(newIterator),
                '(Other)': next(newIterator),
                'Direct': next(newIterator),
                'Organic Search': next(newIterator),
                'Paid Search': next(newIterator),
                'Referral': next(newIterator),
                'Social': next(newIterator)
            })


def main():
    arr = []
    for domain in domains:
        dic = {}
        VIEW_ID = domain
        analytics = initialize_analyticsreporting()
        response = get_report(analytics, VIEW_ID)
        dicto = print2dic(response, dic, domain)
        arr.extend(dic2array(dicto))
    array2csv(arr)


if __name__ == '__main__':
    main()
