"""Hello Analytics Reporting API V4."""
import csv
import datetime
import os
import sys
from apiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials

location = os.getcwd()
domains = []
with open('views.csv') as csvDataFile:
    reader = csv.reader(csvDataFile, delimiter=';')
    for row in reader:
        for item in row:
            if item not in row:
                domains.append('')
            else:
                domains.append(item)

SCOPES = ['https://www.googleapis.com/auth/analytics.readonly']
KEY_FILE_LOCATION = 'client_secrets.json'
VIEW_ID = ''

def choserightchlient_secrets():
    try:
        os.rename(rf'{location}\\client_secrets.json', rf'{location}\\client_secrets_sophia.json')
        os.rename(rf'{location}\\client_secrets_steffen.json', rf'{location}\\client_secrets.json')
    except Exception:
        os.rename(rf'{location}\\client_secrets.json', rf'{location}\\client_secrets_steffen.json')
        os.rename(rf'{location}\\client_secrets_sophia.json', rf'{location}\\client_secrets.json')


def initialize_analyticsreporting():
    """Initializes an Analytics Reporting API V4 service object.

    Returns:
      An authorized Analytics Reporting API V4 service object.
    """
    credentials = ServiceAccountCredentials.from_json_keyfile_name(
        KEY_FILE_LOCATION, SCOPES)

    # Build the service object.
    analytics = build('analyticsreporting', 'v4', credentials=credentials)

    return analytics


def get_report(analytics, VIEW_ID):
    """Queries the Analytics Reporting API V4.

    Args:
      analytics: An authorized Analytics Reporting API V4 service object.
    Returns:
      The Analytics Reporting API V4 response.
    """
    return analytics.reports().batchGet(
        body={
            'reportRequests': [
                {
                    'viewId': VIEW_ID,
                    'dateRanges': [{'startDate': '2020-05-01', 'endDate': '2020-05-31'}],
                    "metrics": [{"expression": "ga:users"}],
                    'dimensions': [{'name': 'ga:channelGrouping'}],
                    # "includeEmptyRows": "true"
                }]
        }
    ).execute()


def print2dic(response, dicto, domain):
    for report in response.get('reports', []):
        for row in report.get('data', {}).get('rows', []):
            dimensions = row.get('dimensions', [])
            dateRangeValues = row.get('metrics', [])
            for i, values in enumerate(dateRangeValues):
                for dimension, value in zip(dimensions, values.get('values')):
                    dicto[dimension] = value

    return dicto


def array2csv(array):
    with open(f'{location}\\Reports\\REPORT_Analytics_Akquisition_{datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")}.csv', 'w',
              newline='') as csvfile:
        fieldnames = ['Organic Search', 'Referral', 'Direct', 'Social', '(Other)', 'Paid Search']
        csvWriter = csv.DictWriter(csvfile, delimiter=';', fieldnames=fieldnames, quoting=csv.QUOTE_NONE)
        csvWriter.writeheader()
        csvWriter.writerows(array)


def main():
    toolbar_width = len(domains)
    arr = []
    sys.stdout.write("[%s]" % (" " * toolbar_width))
    sys.stdout.flush()
    sys.stdout.write("\b" * (toolbar_width + 1))  # return to start of line, after '['
    for domain in domains:
        dic = {}
        VIEW_ID = domain
        try:
            analytics = initialize_analyticsreporting()
            response = get_report(analytics, VIEW_ID)
        except Exception:
            choserightchlient_secrets()
            analytics = initialize_analyticsreporting()
            response = get_report(analytics, VIEW_ID)
        dicto = print2dic(response, dic, domain)
        arr.append(dicto)
        sys.stdout.write("-")
        sys.stdout.flush()
    array2csv(arr)
    sys.stdout.write("]\n")  # this ends the progress bar
    print('finished')


if __name__ == '__main__':
    main()
